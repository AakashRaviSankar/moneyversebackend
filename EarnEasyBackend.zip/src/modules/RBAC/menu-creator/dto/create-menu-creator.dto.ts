export class CreateMenuCreatorDto {}
